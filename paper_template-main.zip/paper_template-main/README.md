A generic starter template for writing an HCI research paper in LaTex
